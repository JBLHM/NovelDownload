package com.xu.webmagic.AfterExtractor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.xu.webmagic.Pipeline.NovelPipeline;
import com.xu.webmagic.main.NovelProcessor;

import com.xu.webmagic.utils.NovelDownloadUrl;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.model.AfterExtractor;

public class NovelAfterExtractor implements AfterExtractor{
	static int flag = 1;//用来判断文件是否删除成功
	//临时目录
	static String tempDir = "E:\\spider\\";
	//小说真正下载目录
	static String baseDir = "D:\\spider\\";
	static File tempDir3=null;
	@Override
	public void afterProcess(Page page) {
		// TODO Auto-generated method stub
		
	}

	//合并小说
	public static String GetTxtOrder(Long maxnumber,String filepath,Map<Long,String> amap) {
		//	url=title+url+"\r\n"+"\r\n"+"\r\n";用一个数组或者map装title和对应的id,即(key,value)
		
		File cfile=new File(baseDir);
		//主文件目录判断是否存在
		 if(!cfile.exists())
		 {
			 cfile.mkdirs();
		 }
		BufferedReader bufferedReader=null;
		try {
			
			//在每一章一个txt时不能将每一章标题插进去,合并时再将标题拼接上读取的txt
				//判断临时目录是否存在
				File readfile=new File(tempDir);
				if(!readfile.isDirectory())
				{
					
					System.out.println("目录不存在");
				}
				//临时目录存在的话进行下一步
				else if(readfile.isDirectory())
				{//按照序号依次读取临时txt
					for(int i=0;i<(maxnumber+1);i++)
					{
//						//遍历amap中的值
//						for (Integer value : amap.values()) {
//						  System.out.println("Value = " + value);
//						}
						 Long j=(long)i;
						 String titleb=amap.get(j);
						 System.out.println("当序号为"+j+"时,titleb的值为"+titleb);
						 String everyfilename="第"+i+"个";
						 String Basefilename=filepath;
						 Basefilename=Basefilename.concat(".txt");
						 everyfilename=everyfilename.concat(".txt");
						 System.out.println("GetTxtOrder.everyfilename="+everyfilename);
						 String tempDira=tempDir.concat(everyfilename);
						 System.out.println("临时文件完整目录GetTxtOrder.tempDira="+tempDira);
						 String BaseDir=baseDir.concat(Basefilename);
						 System.out.println("GetTxtOrder.BaseDir合并完整目录="+BaseDir);
						 //暂时默认为删除文件,以后可以加个选择,选择是否重命名
						 File filetest=new File(BaseDir);
						 if(filetest.exists())
						 {
							 System.out.println("小说名.txt文件已经存在,开始删除");
							
							 //filetest.delete();
						 }
						 try {
						 File reallyfile=new File(tempDira);
						 
						 FileWriter filea=new FileWriter(BaseDir,true);
						 //判断临时文件是否存在
						 if(reallyfile.exists())
						 {
							 System.out.println("tempDira文件存在"+tempDira);
							 //文件存在,则读取到合并txt中
							 try {
								 InputStreamReader inputStreamReader =new InputStreamReader(new FileInputStream(reallyfile),"UTF-8");
								 bufferedReader=new BufferedReader(inputStreamReader);
								 String content=null;
								 
								 while ((content=bufferedReader.readLine())!=null){
									 System.out.println("读取到的内容:"+content);
									 //处理content的空白字符
									 Pattern p = Pattern.compile("\\s*|\t|\r|\n");
									 Matcher m = p.matcher(content);
									 content = m.replaceAll("");
									 content=titleb+"\r\n"+"\r\n"+content+"\r\n"+"\r\n";
									 System.out.println("拼接标题后的内容:"+content);
									 filea.write(content);
								 }
								 
								 } catch (IOException e) {
								 System.out.println("IOException");
								 e.printStackTrace();
								 }
								 finally {
									 try {
										   filea.flush();
										   filea.close();
									   } catch (IOException ex) {
									       ex.printStackTrace();
									   }
									 
								 }//最里层try,catch结束
							
						 }
						 else
						 {
							 System.out.println(everyfilename+"文件不存在");
						 }//最里层if结束
						 }catch(Exception e)
						 {
							 
						 }//最外层try,catch结束
						 
					}//for循环结束,开始进行删除临时文件操作
				}//else if结束
				else
				{
					System.out.println("目录创建出错了");
				}//最外层if结束
			
			
		}catch(Exception e)

		{
			
		}//最外层if结束
		return tempDir;
		
	}
	public static void deleteFile(File file){
	    //判断文件不为null或文件目录存在
	    if (file == null || !file.exists()){
	        flag = 0;
	        System.out.println("文件删除失败,请检查文件路径是否正确");
	        return;
	    }
	    //取得这个目录下的所有子文件对象
	    File[] files = file.listFiles();
	    //遍历该目录下的文件对象
	    for (File f: files){
	        //打印文件名
	        String name = file.getName();
	        System.out.println(name);
	        //判断子目录是否存在子目录,如果是文件则删除
	        if (f.isDirectory()){
	            deleteFile(f);
	        }else {
	            f.delete();
	        }
	    }
	    //删除空文件夹  for循环已经把上一层节点的目录清空。
	    file.delete();
	}
	 public static void main(String[] args) {
		 //爬虫前再一次删除临时文件
		 tempDir3=new File(tempDir);
		 if(tempDir3.exists())
		 {
			 deleteFile(tempDir3);
		 }
		
		 //搜索后跳到这个页面由http://m.shaoshuge.info/html/15/15898/变成http://m.shaoshuge.info/book/15898/
		 //http://m.shaoshuge.info/book/25856/
		 //使用novelpipeline2时更改url为http://www.diyibanzhu9.xyz/13/13426/
	       Spider.create(new NovelProcessor()).addUrl("http://m.shaoshuge.info/book/75456/")
	                .addPipeline(new NovelPipeline()).thread(5).run();
//		 Spider.create(new NovelProcessor2()).addUrl("https://www.diyibanzhu4.pro/14/14249/")
//         .addPipeline(new NovelPipeline2()).thread(5).run();
	        Long maxnumber=NovelDownloadUrl.getmaxnumber();
			System.out.println("从NovelDownloadUrl 获取的maxnumber="+maxnumber);
			String filepath=NovelDownloadUrl.getfilepath();
			System.out.println("从NovelDownloadUrl 获取的filepath="+filepath);
			Map<Long,String> amap=new HashMap<Long,String>();
			amap=NovelDownloadUrl.gettitle();
			//爬虫后删除同名文件
			String a=filepath;
			a=a.concat(".txt");
			a=baseDir.concat(a);
			File b=new File(a);
			if(b.exists())
			{
				System.out.println("先删除同名目录");
				b.delete();
			}
			String tempDir2=GetTxtOrder(maxnumber,filepath,amap);
			System.out.println("Now tempDir2="+tempDir2);
			//爬虫后删除临时文件
			 tempDir3=new File(tempDir);
			 if(tempDir3.exists())
			 {
				 deleteFile(tempDir3);
			 }
			 
			 if (flag == 1){
		            System.out.println("所有的临时文件删除成功！");
		        }
	        //a.afterProcess(page);
	    }
}
