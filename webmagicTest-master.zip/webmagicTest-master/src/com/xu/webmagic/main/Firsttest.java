package com.xu.webmagic.main;
import java.util.List;

import com.xu.webmagic.Pipeline.TestPipeline;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.ConsolePipeline;
import us.codecraft.webmagic.pipeline.JsonFilePipeline;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.Selectable;
public class Firsttest implements PageProcessor {
	//private static String MYURL="http://m.shaoshuge.info/html/15/15898/";
	private Site site = Site.me().setRetryTimes(10).setSleepTime(1000);
	@Override
	public void process(Page page) {
		//String detail_urls_Xpath = "//*div[@class='cover']/div[@class='read']/ul[@class='chapter']/li/a/@href";
		//String detail_urls_Xpath ="//*div[@class='cover']//ul[@class='chapter']//li/a/@href";
		String detail_urls_Xpath ="//div[@id='list']/dl/dd/a/@href";
//		String detail_urls_Xpath ="//html/body/div[2]/ul/li[1]/a";
//		String next_page_xpath = "//html/body/div[3]/a[1]";
		//String next_page_xpath = "//*div[@class='page']/a/@href";
		//String next_page_css = "#homepage_top_pager > div:nth-child(1) > a:nth-child(7)";
		//String title_xpath = "//*div[@class='cover']/div[@class='read']/ul[@class='chapter']/li/a/text()";
		//String title_xpath ="//*div[@class='cover']//ul[@class='chapter']//li/a/text()";
		String title_xpath ="//div[@id='list']/dl/dd/a/text()";
//		String title_xpath ="//html/body/div[2]/ul/li[1]/a/text()";
		
		//String date_xpath = "//span[@id='post-date']/text()";
		
	//page.putField("date", page.getHtml().xpath(date_xpath).toString());

		if (page.getHtml().xpath(detail_urls_Xpath).match()) {
			Selectable detailUrls = page.getHtml().xpath(detail_urls_Xpath);
			page.addTargetRequests(detailUrls.all());
			//.links().regex("http://www\\.xbiquge\\.la/\\w+/\\w+")
		}

		
		page.putField("title", page.getHtml().xpath(title_xpath).all().toString());
		if (page.getResultItems().get("title") == null) {
		page.setSkip(true);
			System.out.println("null");
		}
				
			}
	@Override
	public Site getSite() {
		// TODO Auto-generated method stub
		return null;
	}
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		TestProcessor processor = new TestProcessor();
		Spider.create(processor)
				.addUrl("http://www.xbiquge.la/13/13959/")
				.addPipeline(new ConsolePipeline()).thread(5).run();
		//改造将原本的new TestPipeline()替换成new JsonFilePipeline("D:\\webmagic\\")
		//https://www.kanmaoxian.com/99/99212/index.html
		//http://www.cnblogs.com/dick159/default.html?page=1
		//https://www.kanmaoxian.com/137/137988/index.html
	}

}
