package com.xu.webmagic.main;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.processor.PageProcessor;

public class NovelProcessor implements PageProcessor {

    private Site site = Site.me().setRetryTimes(3).setSleepTime(1000).setTimeOut(10000)
    		.addHeader("Referer", "http://m.shaoshuge.info");
   static  int k=0;

    @Override
    public void process(Page page) {
    	//修改版:假设搜索得到一系列结果,然后你选择了某一项
    	//采用CSS选择抽取
    	//注意:/p也属于p元素
    	if(page.getUrl().regex("http://m.shaoshuge.info/book/[\\d]+").match())
    	{
    		System.out.println("开始进入目录页");
    		String author=page.getHtml().$("div.block_txt2>p:nth-child(4)>a").$("a","text").toString();
        	
        	//System.out.println("接着:"+page.getHtml().$("div.block_txt2").toString());
        	System.out.println("作者是"+author);
        	page.putField("author", author);
        	//书的类别
        	String family=page.getHtml().$("div.block_txt2>p:nth-child(5)>a").$("a","text").toString();
        	
        	System.out.println("书的类别family=:"+family);
        	page.putField("family", family);
        	//把查看目录的链接加入
        	String sc=page.getHtml().$("div.ablum_read >span:nth-child(2)").links().toString();
        	System.out.println("查看目录sc=:"+sc);
        	 page.addTargetRequest(page.getHtml().$("div.ablum_read >span:nth-child(2)").links().toString());
        	
        	
        	//进行字符串转换,将
        	//http://m.shaoshuge.info/html/15/15898/变成http://m.shaoshuge.info/html/15/
        	//方法①
        	
        	String t=sc;
        	int idx = t.lastIndexOf("/");
        	t=t.substring(0,idx);
        	//t=t.substring(t.split("/").length-1, t.split("/").length);
        	System.out.println("t="+t);
        	 System.out.println("一开始"+page.getUrl());
        	//t=t.split("/")[t.split("/").length-1];
        	//方法②
//        	 int idx = str.lastIndexOf("/");
//        	 str = str.substring(idx + 1, str.length());
        	//区分目录和文字:
      	//目录正则表达式:http://m.shaoshuge.info/html/15/d+
        //文章正则表达式:http://m.shaoshuge.info/html/15/d+/d+
        	
    	}
//    	 if(page.getUrl().regex("http://m.shaoshuge.info/html/15/[\\d]{2,3}") != null)
    	 if(page.getUrl().regex("http://m.shaoshuge.info/html/[\\d]{2,3}") != null)
         {
         //程序无法运行解决方法 :http://webmagic.io/docs/zh/posts/ch4-basic-page-processor/spider-config.html
        	 System.out.println("进入条件之后"+page.getUrl()	+"\n"+page.getRequest().toString());
        
        	  System.out.println("开始进入文章页");
        	//"http://www.mmonly.cc/ktmh/hzw/[\\d]+" :图片网页链接
            // 图片合集里的下一页
          //Selectable links = page.getHtml().$("#pb_next").links();
         // System.out.println("links="+page.getHtml().$("#pb_next"));
        //System.out.println(page.getHtml().$("div.page > a:nth-last-child(2)"));
          //links.toString() != "##"
            //if (links != null && links.toString() != "##")
              // page.addTargetRequest(links.toString());
            // 抓取内容,标签链接
          //page.getHtml().xpath("//div[@id='nr1']//br").
           //String img = page.getHtml().$("#nr1").toString();
            String img=page.getHtml().xpath("//div[@id='nr1']//text()").toString();
            //下面这行代码意思:不加会报错page status code error, page https://www.mmonly.cc/ktmh/hzw/303467_3.html , code: 403
           String title=page.getHtml().xpath("//div[@id='nr_title']//text()").toString();
            //不加下面一行代码是
            //img=<img alt="海贼王路飞热血长篇动漫电脑壁纸图片" src="https://t1.hxzdhn.com/uploads/tu/201910/9999/bfa406348b.jpg">
            //加这行代码后是img=https://t1.hxzdhn.com/uploads/tu/201903/9999/058a178220.jpg
 			//图片名字
           //书名
           String bookname=page.getHtml().xpath("//h1[@id='_52mb_h1']//text()").toString();
           
           
            
            page.putField("bookname", bookname);
            //System.out.println("第"+k+"个"+"NovelProcessor.bookname="+bookname);
            page.putField("title", title);
            System.out.println("title="+title);
           //System.out.println("第"+k+"个"+"NovelProcessor.title="+title);
           //-----------------------------------------------------
           //------------------①去重----②排序(按照目录排序) ③给每一章内容加上标题 ④获取书名 ----------------------------
           //排序思路,给待下载的url加个标号,1,2,3...,在下载url时根据标号排序;根据章节排序,将章节名放在img前,每一个img排序,用数组装img
           //-----------------------------------------------------
 		// System.out.println("第"+k+"个"+"NovelProcessor.img="+img);
 			//第0个NovelProcessor.img=<div id="nr1">
 			//img = img.substring(img.indexOf("src=\"") + 5, img.length() - 2);
 			page.putField("img", img);
 			
            
 			
         }
        if (page.getUrl().toString().startsWith("http://m.shaoshuge.info/html/")) {
//        	 if (page.getUrl().regex("http://m.shaoshuge.info/html/[\\d]+")!=null) {
            // System.out.println("page.gethtml="+page.getHtml().toString());
            // 获取详情页面
            page.addTargetRequests(page.getHtml().css("li").css("a").links().all());
            System.out.println("①"+page.getHtml().css("li").css("a"));
            // 获取下一页，倒数第2个a标签
            page.addTargetRequest(page.getHtml().$("div.page > a:nth-last-child(2)").links().toString());
            System.out.println("②"+page.getHtml().$("div.page > a:nth-last-child(2)"));
            System.out.println("进入条件前"+page.getUrl());
            System.out.println("报头信息:"+site.getHeaders().toString());
            
        }
     
        else
        {
        	 System.out.println("否则,url=="+page.getUrl().toString());
        }
        k++;
    }
       //if (page.getUrl().regex("http://m.shaoshuge.info/html/15/15898/[\\d]+") != null)
        
    

    @Override
    public Site getSite() {
        return site;
    }
//http://m.shaoshuge.info/html/15/15898_35/ http://m.shaoshuge.info/html/15/15898/
//    public static void main(String[] args) {
//        Spider.create(new NovelProcessor()).addUrl("http://m.shaoshuge.info/html/15/15898_35/")
//                .addPipeline(new NovelPipeline()).thread(5).run();
//    }
}