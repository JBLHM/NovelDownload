package com.xu.webmagic.main;
import java.util.List;

import com.xu.webmagic.Pipeline.TestPipeline;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.JsonFilePipeline;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.Selectable;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;

public class SecondTest implements PageProcessor{

	private Site site = Site.me().setRetryTimes(10).setSleepTime(1000);

	@Override
	public void process(Page page) {
	System.err.println(page.getUrl());
	if(!page.getUrl().regex("http://www.biquge.com.tw/16_16263/[0-9]{7}.html").match()){
        //加入满足条件的链接
		System.err.println("1"+page.getHtml().xpath("//*[@id=\"wrapper\"]/div/div/dl/dd/a/@href").all());
		List<String> urls =page.getHtml().xpath("//*[@id=\"wrapper\"]/div/div/dl/dd/a/@href").all();
		for(String url : urls){
			url="http://www.biquge.com.tw"+url;
		}
        page.addTargetRequests(urls);
    }else{       System.err.println("2");                      
        System.out.println("抓取的内容："+
                page.getHtml().xpath("//*[@id=\"content\"]/text()").get()
                );
    }
	}

	@Override
	public Site getSite() {
		return this.site;
	}

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		TestProcessor processor = new TestProcessor();
		Spider.create(processor)
				.addUrl("http://www.cnblogs.com/dick159/default.html?page=1")
				.addPipeline(new JsonFilePipeline("D:\\webmagic\\")).thread(5).run();
	}
}
