package com.xu.webmagic.main;
import com.xu.webmagic.Pipeline.MyPipeline;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.Selectable;

public class PicProcessor implements PageProcessor {

    private Site site = Site.me().setRetryTimes(3).setSleepTime(1000).setTimeOut(10000);

    @Override
    public void process(Page page) {
        if (page.getUrl().toString().startsWith("http://www.mmonly.cc/ktmh/hzw/list_")) {
            // System.out.println(1);
            // 获取详情页面
            page.addTargetRequests(page.getHtml().$("div.item_t > div.img > div.ABox > a").links().all());
            System.out.println("①"+page.getHtml().$("div.item_t > div.img > div.ABox > a"));
            // 获取下一页，倒数第2个a标签
            page.addTargetRequest(page.getHtml().$("#pageNum > a:nth-last-child(2)").links().toString());
            System.out.println("②"+page.getHtml().$("#pageNum > a:nth-last-child(2)"));
            System.out.println("旧Url()=http://www.mmonly.cc/ktmh/hzw/list_34_1.html");
        } else if (page.getUrl().regex("http://www.mmonly.cc/ktmh/hzw/[\\d]+") != null) {
        	System.out.println("page.getUrl()=https://www.mmonly.cc/ktmh/hzw/114834.html");
        	System.out.println("开始进入文章页"+page.getUrl().regex("http://www.mmonly.cc/ktmh/hzw/[\\d]+"));
            // System.out.println(page.getUrl());
        	//"http://www.mmonly.cc/ktmh/hzw/[\\d]+" :图片网页链接
            // 图片合集里的下一页
          Selectable links = page.getHtml().$("#nl > a").links();
          System.out.println("③"+page.getHtml().$("#nl > a"));
          //links.toString() != "##"
            if (links != null && links.toString() != "##")
               page.addTargetRequest(links.toString());
            // 抓取内容,标签链接
           String img = page.getHtml().$("#big-pic p img").toString();
           System.out.println("抓取内容,标签链接"+img);
            if (img == "null")
            	//使用jQuery ##big-pic a img代表寻找id=big-pic 的元素下的a下的img元素
               img = page.getHtml().$("#big-pic a img").toString();
            //下面这行代码意思:不加会报错page status code error, page https://www.mmonly.cc/ktmh/hzw/303467_3.html , code: 403
           
            //不加下面一行代码是
            //img=<img alt="海贼王路飞热血长篇动漫电脑壁纸图片" src="https://t1.hxzdhn.com/uploads/tu/201910/9999/bfa406348b.jpg">
            //加这行代码后是img=https://t1.hxzdhn.com/uploads/tu/201903/9999/058a178220.jpg
			//图片名字
		
			
            img = img.substring(img.indexOf("src=\"") + 5, img.length() - 2);
			String picturename=page.getHtml().$("div.photo>div>h1").toString();
			picturename=picturename.substring(picturename.indexOf("h1") + 3, picturename.indexOf("span") - 2);
			 System.out.println("alt=="+picturename);
            System.out.println("img="+img);
            page.putField("img", img);
            page.putField("picturename", picturename);
			
			
        }
    }

    @Override
    public Site getSite() {
        return site;
    }

    public static void main(String[] args) {
        Spider.create(new PicProcessor()).addUrl("http://www.mmonly.cc/ktmh/hzw/list_34_1.html")
                .addPipeline(new MyPipeline()).thread(5).run();
    }
}