package com.xu.webmagic.main;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.processor.PageProcessor;
//#适用于看毛线电脑版
public class Novel3Processor implements PageProcessor  {

    private Site site = Site.me().setRetryTimes(3).setSleepTime(1000).setTimeOut(10000)
    		.addHeader("Referer", "https://www.kanmaoxian.com").setDomain("https://www.kanmaoxian.com").addCookie("dotcomt_user","code4craft");
    //https://www.kanmaoxian.com/139/139654/index.html对应正则表达式https://www\\.kanmaoxian\\.com/\\d{0,3}/\\d{0,6}/index\\.html
    //注意d{0,3}指前面有3个数字,如139
   static  int k=0;
   public static final String URL_LIST="https://www\\.kanmaoxian\\.com/\\d{0,3}/\\d{0,6}/index\\.html";
   public static final String URL_POST="https://www\\.kanmaoxian\\.com/\\d{0,3}/\\d{0,6}/\\d{0,9}\\.html";
    @Override
    public void process(Page page) {
    	//修改版:假设搜索得到一系列结果,然后你选择了某一项
    	//采用CSS选择抽取
    	//注意:/p也属于p元素
    	
    	//System.out.println("当前网页状态是:"+page.getStatusCode());
    	//书名
//    	if(page.getUrl().toString().compareTo("https://www.kanmaoxian.com/139/139654/index.html")==0)
//    	{
    		
//    	}
//   	
   	 
   	
    	if(page.getUrl().regex(URL_LIST).match())
    	{
    		//System.out.println("开始进入目录页");
//    		String author=page.getHtml().xpath("//section[@class='ml_title']/span//text()").toString();
//        	
//        	//System.out.println("接着:"+page.getHtml().$("div.block_txt2").toString());
//        	System.out.println("作者是"+author);
//        	page.putField("author", author);
    		
//   		 String bookname=page.getHtml().xpath("//section[@class='ml_title']/h1//text()").toString();
//   		 page.putField("bookname", bookname);
//   	     System.out.println("书名是"+bookname);	
        	 //目录页链接
        	 String category=page.getHtml().xpath("//section[@class='ml_main']/dl/dd/a").links().all().toString();
        	 page.addTargetRequests(page.getHtml().xpath("//section[@class='ml_main']/dl/dd/a").links().all());
        	 //System.out.println("目录链接有是"+category);
        	
    	}
        
    	
    	else if(page.getUrl().regex(URL_POST).match())
         {
        
    		 
        	
        
    		String title=page.getHtml().xpath("//h2//text()").toString();
            
            page.putField("title", title);
          //System.out.println("每一章标题title="+title);
//            if (page.getResultItems().get("title") == null) {
//    			page.setSkip(true);
//    		}
            String img=page.getHtml().xpath("//div[@class='yd_text2']//text()").toString();
           //System.out.println("捕捉的文字="+img+"\n"+"长度"+img.length());
          //如果正文是图片的话
           if(img.indexOf("divimage")!=-1||img.length()<15)
           {
        	   //获取的img不是正文
        	   img=page.getHtml().$("div.divimage>img").$("img","src").toString();
        	   System.out.println("捕捉的图片链接="+img);
           }
           else
           {
        	   //正常的文字
        	   
           }
           
 			page.putField("img", img);
 			// System.out.println("进入条件前"+page.getUrl());
             //System.out.println("报头信息:"+site.getHeaders().toString());
            //下一章链接:
//             String nexta=page.getHtml().$("div.fanye>a:nth-child(3)").$("a","text").toString();
//             page.addTargetRequest( page.getHtml().$("div.fanye>a:nth-child(3)").links().toString());
            // System.out.println("下一章文本是"+nexta+"链接是"+page.getHtml().$("div.fanye>a:nth-child(3)").links().toString());
   		 String bookname=page.getHtml().xpath("//div[@class='read_m']/h1/a//text()").toString();
   		 page.putField("bookname", bookname);
   	     //System.out.println("书名是"+bookname);	
         }
      
     
        else
        {
        	// System.out.println("否则,url=="+page.getUrl().toString());
        }
        k++;
    }
       //if (page.getUrl().regex("http://m.shaoshuge.info/html/15/15898/[\\d]+") != null)
        
    

    @Override
    public Site getSite() {
        return site;
    }
//http://m.shaoshuge.info/html/15/15898_35/ http://m.shaoshuge.info/html/15/15898/
//    public static void main(String[] args) {
//        Spider.create(new NovelProcessor()).addUrl("http://m.shaoshuge.info/html/15/15898_35/")
//                .addPipeline(new NovelPipeline()).thread(5).run();
//    }
}