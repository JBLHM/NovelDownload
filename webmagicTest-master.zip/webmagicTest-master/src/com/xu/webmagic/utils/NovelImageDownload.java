package com.xu.webmagic.utils;


import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
//----千万不能在这里删除文件,每一次处理一个url,NovelPipeline
//都会调用这个类,若是在这写删除函数,会把上次的结果删掉-------------//

public class NovelImageDownload {
    /**
     * 传入要下载的图片的url列表，将url所对应的图片下载到本地
     */
	//任务①检查文件是否存在,即 是否存在baseDir②将下载的小说全丢到一个文档中
    
    static int j=0;
    static String imagetype=null;
    static String baseDir = "D:\\spider\\";
    // 下载一张图片
    public static void downloadPicture2(String u,String bookname,String picturename) {
       
        baseDir=baseDir+bookname+"\\";
        System.out.println("一开始的baseDir:"+baseDir);
        URL url = null;
        System.out.println("一开始的url:"+u);
        
       //现在修改成picturename
        //concat(String):字符串拼接函数
        
        //增加判断图片链接是gif还是jpg之类的
        int q=u.lastIndexOf(".");
        
        imagetype=u.substring(q, u.length());
        System.out.println("获取到的图片类型是"+imagetype);
        String name =picturename.concat(imagetype);
      //替换title里的\字符成-字符
        name=name.replaceAll("/","-");
        //去除【和】符号
        name=name.replaceAll("】","");
        name=name.replaceAll("【","");
        //删除首尾空格
        name=name.trim();
      
        
        System.out.println("第"+j+"个文件的"+"文件名："  + name);
       j++;
        try {
            url = new URL(u);
            //InputStream is = new URL(path).openStream();相当于String url.

//HttpURLConnection conn = (HttpURLConnection)url.openConnection();
//openStream打开网络地址获取文件流
//InputStream is = conn.getInputStream();
             //所创建文件目录
    		File f = new File(baseDir); 
    		if(!f.exists()){
    			System.out.println("未创建目录");
    			f.mkdirs(); //创建目录
    			
    		}
    		else
    		{
    			System.out.println(baseDir+"目录已存在");
    		}
//    		String fileName = "abc.txt"; //文件名及类型
//    		File file = new File(baseDir,fileName);
//    		if(!file.exists()){ //surround with try/catch
//    			try { 
//    				file.createNewFile();
//    			} catch (IOException e) {
//    				// TODO Auto-generated catch block
//    				e.printStackTrace();
//    			}
//    		}

    		File fa=new File(baseDir+name);
    		if(fa.exists())
    		{
    			System.out.println("fa文件已存在");
    		}
    		else
    		{
    			fa.getParentFile().mkdir();
    			
    			System.out.println("fa文件不存在,父目录="+fa.getParentFile().toString());
    			
    		}
    		System.out.println("第"+j+"个fa路径"+fa.getPath().toString());
            DataInputStream dataInputStream = new DataInputStream(url.openStream());
            FileOutputStream fileOutputStream = new FileOutputStream(fa);

            byte[] buffer = new byte[1024 * 50];
            int length;
            //dataInputStream输入字节流按照buffer类型byte读取然后存放到length中
            while ((length = dataInputStream.read(buffer)) > 0) {
            	//fileOutputStream输出,从length中读取数据输出到fileOutputStream
                fileOutputStream.write(buffer, 0, length);
            }
            System.out.println("已经下载：" + baseDir + name);
            dataInputStream.close();
            fileOutputStream.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
	
}