package com.xu.webmagic.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NovelDownloadUrl {
	
	static int j=1;
	//获取最大章节数
	static long maxnumber=(long) 0;
	static String booknamea="";
	static String titlea="";
	static int chinesenumber=0;
	static Boolean chinese=false;
	static String tempDir = "E:\\spider\\";
	static Map<Long,String> amap=new HashMap<Long,String>();
public static void downloadnovel(String url,String bookname,String title)
{
	//判断目录是否存在  if (dir.isDirectory()),创建目录dir.mkdir();
	//判断文件是否存在if (file.exists())
	if(url==null)
    {
    	url="章节获取失败";
    }
    if(title==null)
    {
    	title="文章标题获取失败";
    }
    //文章排序编号
    long number=(long)0;
    number=handeltitle(title);
    System.out.println("由标题得到序号:"+number);
    title+="\r\n";
    //删除所有空格,replaceAll()无法替换空白字符,str = .replaceAll("\\s*", "")则可以

    //url=url.replaceAll(" ","");
    //url = url.replaceAll("\\s*|\t|\n|\r", ""); 
    Pattern p = Pattern.compile("\\s*|\t|\r|\n");
    Matcher m = p.matcher(url);
    url = m.replaceAll("");
    //System.out.println("删除空格后url="+url);
    //字符串前面加四个空格
    //url="    "+url;
    titlea=title;
    //将title和对应的id存到map中
    amap.put(number,titlea);
   
	url=url.replaceAll("更多&#'尽在'ｗ'ｗ'ｗ.''Ｂ'.'Ｅ'第&#站","");
      // url = url.substring(url.indexOf("src=\"") + 5, url.length() - 2);
     // System.out.println("url="+url);
	  //任务:①什么时候一部小说结束,第二个:将txt合并成一个txt
//	  String baseDir = "D:\\spider\\";
//	 
//	 
	  String filename=bookname;
	  booknamea=bookname;
//	  filename=filename.concat(".txt");
//      String filePath=baseDir.concat(filename);
//      FileWriter fwriter = null;
      //执行该操作前要先删掉合并的文件名.txt,
      //每一章都是一个txt
      writeevery(url,number);
//      File filea = new File(filePath.concat(filename));
//      if(filea.exists())
//      {
//    	  System.out.println("文件已经存在");
//    	  filea.delete();
//      }
//      else
//      {
//    	  System.out.println("文件不存在");
//    	  
//      }
//	  
      
      //合并txt文件
     // GetTxtOrder(maxnumber,bookname);
      //管理url顺序
//      try {
//          // true表示不覆盖原来的内容，而是加到文件的后面。若要覆盖原来的内容，直接省略这个参数就好
//          fwriter = new FileWriter(filePath, true);
//         
//          if(url!=null)
//          {
//        	  //这里的url是从txt中读取出来的
//          fwriter.write(url);
//          }
//          
//      } catch (IOException ex) {
//          ex.printStackTrace();
//      } finally {
//          try {
//              fwriter.flush();
//              fwriter.close();
//          } catch (IOException ex) {
//              ex.printStackTrace();
//          }
//      }
      j++;
}
public static Long handeltitle(String title)
{
	 //获得序号以方便排序
    //获取章节信息,以方便排序
		String str=title;
		//System.out.println("str="+str);
		String str2="";
		
		//去除字符串空格提取数字(遇到-取前面的数字)
		str=str.trim();
		//将字符串转换成数组
		char[]array=str.toCharArray();
		for(int q=0;q<str.length();q++)
		{
			//处理20-29这种的章节名
			if(array[q]=='-')
			{
				int i = str.indexOf("-");
				str = str.substring(0,i);
			}
			
			//处理第...章这种的章节名
			if(array[q]=='章')
			{
				//第11章这种的处理方式
				int i = str.indexOf("章");
				str = str.substring(0,i);
				
				
			}
			
		}
		//章节817后的txt带有标题
		String strm=str;
		if(str!=null&&!"".equals(str))
		{   
			for(int p=0;p<str.length();p++)
			{
				
				
				if(str.charAt(p)>=48&&str.charAt(p)<=57)
				{
					str2+=str.charAt(p);
					//System.out.println("进入正常纯数字");
					chinese=false;
				}
				//调用处理中文目录处理函数,返回一个字符串,如第十一章
				else
				{
					//System.out.println("请注意,进入中文目录");
					char qq=str.charAt(p);
				    int n=0;
				
					if(qq=='第')
					{
						n = strm.indexOf("第");
						//System.out.println("n="+n);
					}
					else 
					{
						n=99;
					}
					if(n!=99)
					{
						strm = strm.substring(n+1,strm.length());
						chinesenumber=handelChinesecategory(strm);
					}
					else
					{
						chinesenumber=handelChinesecategory(strm);
						//System.out.println("进入chinesenumber结果为0的判断语句");
					}
					 
					
					
					//System.out.println("strm="+strm+"chinesenumber的结果"+chinesenumber);
					
					
				}
			}
		}
		
	// System.out.println("循环后str2="+str2);	
      //
      Long number=(long) 0;
      try
      {
    	  if(chinese==true)
    	  {
    		  number=(long) chinesenumber;
    	  }
    	  else
    	  {
    		  number=Long.parseLong(str2);
    	  }
    	 
    	 
    	  
      }catch(Exception e)
      {
    	  number=(long) 0;
    	//  System.out.println("number的值为空");
      }
      //一般章节不会超过6000,如果有number>6000,则取得number前3位数
      if(number>6000)
      {
    	  String t=number.toString();
    	  //System.out.println("一开始t="+t);
    	  //保留3位,千万不能只写t.substring(0,3)不写t=t.substring(0,3),否则t的值不变化;
    	  t=t.substring(0,3);
    	  number=Long.parseLong(t);
    	  //System.out.println("t="+t);
    	 // number=(long) Math.floor(number/10);
      }
     
      if(maxnumber<number)
      {
    	  maxnumber=number;
      }
      //System.out.println("maxnumber="+maxnumber);
	return number;
}

//每一章生成一个txt
public static void writeevery(String url,Long number)
{
	 FileWriter filea = null;
	 String everyfilename="第"+number+"个";
	
	 File cfile=new File(tempDir);
	 if(!cfile.exists())
	 {
		 cfile.mkdirs();
	 }
	 everyfilename=everyfilename.concat(".txt");
	 String tempDira=tempDir.concat(everyfilename);
	 
	 //System.out.println("writeevery.url="+url);
   try {
   // true表示不覆盖原来的内容，而是加到文件的后面。若要覆盖原来的内容，直接省略这个参数就好
	   filea=new FileWriter(tempDira,true);
  
   if(url!=null)
   {
 	  //这里的url是从txt中读取出来的
	   filea.write(url);
   }
   
} catch (IOException ex) {
   ex.printStackTrace();
} finally {
   try {
	   filea.flush();
	   filea.close();
   } catch (IOException ex) {
       ex.printStackTrace();
   }
}
}
//filepath:爬取的小说名
//按照txt文件名字的顺序读取txt,再从选择的txt中读取文本内容写到everyDir中

public static long getmaxnumber()
{
	return maxnumber;
}
public static String getfilepath()
{
	return booknamea;
}
public static Map<Long,String> gettitle()
{
	return amap;
}
//将中文转换成数字
public static int handelChinesecategory(String chineseNum)
{
	
	 //System.out.println("处理中文="+chineseNum);
	
    char[] cnArr = new char [] {'一','二','三','四','五','六','七','八','九'};
 	char[] chArr = new char [] {'十','百','千','万','亿'};

 	//最后的结果
 	int result = 0;
    int temp = 1;
    int count = 0;//

	 for (int i = 0; i < chineseNum.length(); i++) {
         boolean b = true;//判断是否是chArr
         char c = chineseNum.charAt(i);
         
       //第二十三章->temp=2 b=false->复位b=true,temp=20 count=1->复位b=true,result=20 temp=1 count=0 temp=3 b=false
         //仅使用于第一百二十六章这种的
         for (int j = 0; j < cnArr.length; j++) {//非单位，即数字
             if (c == cnArr[j]) {
                 if(0 != count){//添加下一个单位之前，先把上一个单位值添加到结果中
                     result += temp;
                     temp = 1;
                     count = 0;
                 }
                 // 下标+1，就是对应的值
                 temp = j + 1;
                 b = false;
                 break;
             }
         }
         if(b){//单位{'十','百','千','万','亿'}
             for (int j = 0; j < chArr.length; j++) {
                 if (c == chArr[j]) {
                     switch (j) {
                     case 0:
                         temp *= 10;
                         break;
                     case 1:
                         temp *= 100;
                         break;
                     case 2:
                         temp *= 1000;
                         break;
                     case 3:
                         temp *= 10000;
                         break;
                     case 4:
                         temp *= 100000000;
                         break;
                     default:
                         break;
                     }
                     count++;
                 }
             }
         }
         if (i == chineseNum.length() - 1) {//遍历到最后一个字符
             result += temp;
         }
     }
  


	 chinese=true;
	
	//System.out.println("从中文目录获得的title是"+result);
	return result;
	
}
}
