package com.xu.webmagic.Pipeline;

import com.xu.webmagic.utils.UrlFileDownloadUtil;

import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

public class MyPipeline implements Pipeline {

    @Override
    public void process(ResultItems resultItems, Task task) {
        // System.out.println(resultItems.getRequest().getUrl());
        String url = resultItems.get("img").toString();
        System.out.println("MyPipeline.url="+url);
        String picturename=resultItems.get("picturename").toString();
        UrlFileDownloadUtil.downloadPicture2(url,picturename);
        //NovelDownload.downloadPicture2(url,picturename);
    }
}