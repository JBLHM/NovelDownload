package com.xu.webmagic.Pipeline;



import java.util.Arrays;

import com.xu.webmagic.utils.NovelImageDownload;
import com.xu.webmagic.utils.NovelDownloadUrl;

import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

public class Novel3Pipeline implements Pipeline {

    @Override
    public void process(ResultItems resultItems, Task task) {
        // System.out.println(resultItems.getRequest().getUrl());
    	 int k=0;
    	 String bookname=null;
        String url = resultItems.get("img").toString();
       bookname = resultItems.get("bookname").toString();
        String title = resultItems.get("title").toString();
        
        
      //  System.out.println("当是第"+k+"个时title="+title);
        //urling picturename=resultItems.get("picturename").tourling();
        //UrlFileDownloadUtil.downloadPicture2(url,picturename);
        //NovelDownload.downloadPicture2(url,picturename);
        //第一个br和第二个br之间删掉&nbsp;这个字符串,然后在第二个br前加个换行符
         //bookname="与舰娘的二三事";
      //本类只能做保存工作,不能做数据处理工作
        if(url.indexOf(".gif")!=-1)
        {
     	   //获取的img不是正文,调用图片下载
        	NovelImageDownload.downloadPicture2(url,bookname, title);
        }
        else
        {
     	   //正常的文字下载
        	 NovelDownloadUrl.downloadnovel(url,bookname,title);
        }
//        System.out.println("Novel3Pipeline里获取的url"+url);
//        NovelDownloadUrl.downloadnovel(url,bookname,title);
       
        //爬取到的结果显示在控制台,修改方法:①参考new JSONPipelinr() ②给url添加br标签
    }
}